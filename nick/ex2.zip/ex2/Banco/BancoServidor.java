package Banco;

import CalcServer.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BancoServidor {

    public static void main(String[] args) {

        try {
            ServerSocket servidor = new ServerSocket(1233);
            // while (!sair) {
            Socket cliente = servidor.accept(); //recebe um cliente
            System.out.println("Cliente recebido");

            Thread t = new Thread() {
                public void run() {
                    Boolean sair = false;
                    int Saldo = 1000;
                    try {
                        //   while (!calculado) {
                        DataInputStream in = new DataInputStream(cliente.getInputStream());
                        DataOutputStream out = new DataOutputStream(cliente.getOutputStream());
                        out.writeUTF("Bem Vindo ao Banco! \n O que deseja fazer? \nDigite: \n 0 para sair \n 1 para deposito \n 2 para saque \n 3 para consultar o saldo");

                        while (!sair) {
                            int ValorOperacao = 0;
                            switch (Integer.parseInt(in.readUTF())) {
                                case 0:
                                    sair = true;
                                    cliente.close();
                                case 1:
                                    out.writeUTF("Digite o valor que deseja depositar");
                                    ValorOperacao = Integer.parseInt(in.readUTF());
                                    out.writeUTF("Depositou: " + ValorOperacao + "\nEscolha a nova Operacao \n 0 para sair \n 1 para deposito \n 2 para saque \n 3 para consultar o saldo");
                                    Saldo = Saldo + ValorOperacao;
                                    break;
                                case 2:
                                    out.writeUTF("Digite o valor que deseja sacar");
                                    ValorOperacao = Integer.parseInt(in.readUTF());
                                    Saldo = Saldo - ValorOperacao;
                                    out.writeUTF("Sacou: " + ValorOperacao + "\nEscolha a nova Operacao \n 0 para sair \n 1 para deposito \n 2 para saque \n 3 para consultar o saldo");
                                    break;
                                case 3:
                                    out.writeUTF("Saldo: " + Saldo + "\nEscolha a nova Operacao \n 0 para sair \n 1 para deposito \n 2 para saque \n 3 para consultar o saldo");
                                    break;

                                default:
                                    out.writeUTF("O numero digitado nao equivale a uma operacao");
                                    break;
                            }
                        }
                        //   }
                    } catch (Exception e) {
                        System.out.println("Erro em um dos clientes");
                    }
                }
            };

            t.start();

            // }
        } catch (IOException ex) {
            System.out.println("Porta já utilizada");
        }
    }
}
