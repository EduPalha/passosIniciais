package Banco;

import CalcServer.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BancoCLiente {

    public static void main(String[] args) {
        try {
            Scanner ler = new Scanner(System.in);
            int Numero = 0;

            Socket cliente = new Socket("localhost", 1233);

            DataOutputStream out = new DataOutputStream(cliente.getOutputStream());
            DataInputStream in = new DataInputStream(cliente.getInputStream());
            while (true) {
                String resposta = in.readUTF();
                if (resposta != null && !resposta.isEmpty()) {
                    System.out.println(resposta);
                    Numero = ler.nextInt();
                    out.writeUTF(Integer.toString(Numero));
                }
            }

        } catch (IOException ex) {
            System.out.println("Servidor não encontrado");
        }
    }

}
