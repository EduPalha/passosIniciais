package CalcServer;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CalcServidor {

    public static void main(String[] args) {

        try {
            ServerSocket servidor = new ServerSocket(1234);
            // while (!sair) {
            Socket cliente = servidor.accept(); //recebe um cliente
            System.out.println("Cliente recebido");

            Thread t = new Thread() {
                public void run() {
                    Boolean sair = false;
                    try {
                        int x, y, resultado;
                        //   while (!calculado) {
                        DataInputStream in = new DataInputStream(cliente.getInputStream());
                        DataOutputStream out = new DataOutputStream(cliente.getOutputStream());
                        while (!sair) {

                            out.writeUTF("Digite o primeiro valor");
                            x = Integer.parseInt(in.readUTF());

                            out.writeUTF("Digite o segundo valor");
                            y = Integer.parseInt(in.readUTF());

                            out.writeUTF("Agora escola a Operacao \n 0 para sair \n 1 + \n 2 - \n 3 * \n 4 /");

                            switch (Integer.parseInt(in.readUTF())) {
                                case 0:
                                    sair = true;
                                case 1:
                                    resultado = x + y;
                                    out.writeUTF("Resultado: " + resultado);
                                    break;
                                case 2:
                                    resultado = x - y;
                                    out.writeUTF("Resultado: " + resultado);
                                    break;
                                case 3:
                                    resultado = x * y;
                                    out.writeUTF("Resultado: " + resultado);
                                    break;
                                case 4:
                                    resultado = x / y;
                                    out.writeUTF("Resultado: " + resultado);
                                    break;
                                default:
                                    out.writeUTF("O numero digitado nao equivale a uma operacao");
                                    break;
                            }
                        }
                        //   }
                    } catch (Exception e) {
                        System.out.println("Erro em um dos clientes");
                    }
                }
            };

            t.start();

            // }
        } catch (IOException ex) {
            System.out.println("Porta já utilizada");
        }
    }
}
