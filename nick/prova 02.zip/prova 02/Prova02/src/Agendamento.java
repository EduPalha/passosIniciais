
public class Agendamento {
    
    public int ID;
    public int ID_Funcionario;
    public String data;
    public String hora;
    public String local;
    public String tipoCompromisso;
    
}
