import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmClasses extends javax.swing.JFrame {

    
    MySQLR mysqlr;
    Connection conn;
    Statement stmt;
    ResultSet rs = null;
    DefaultTableModel model;
    Classe Cadastro;
    int ID;
    
    public FrmClasses() {
        initComponents();
        setLocationRelativeTo(this);
        mysqlr = new MySQLR();
        model = (DefaultTableModel)(TblRegistros.getModel());
        conectar();
        Cadastro = new Classe();
        
    }

    public void limparCampos(){
        TxtDescricao.setText("");
        TxtForca.setText("");
        TxtHP.setText("");
        TxtDefesa.setText("");
        TxtDestresa.setText("");

    }
    
    public void conectar(){
        boolean connected = mysqlr.connect("localhost", "3306", "rpg", "root", "ik9rru2j");
        if (connected) {
            jLabelDatabase.setText("ON");
        } else {
            jLabelDatabase.setText("OFF");
        }
    }
    
    public void inserir(Classe obj){
        String query = "INSERT INTO Classes (descricao, forca, hp, destresa, defesa) "
                + "values ('"+obj.Descricao+"', "+obj.Forca+", "+obj.HP+", "+obj.Destresa+", "+obj.Defesa+")";
        int status = mysqlr.executeUpdate(query);
        if (status == 1) {
            limparCampos();
            JOptionPane.showMessageDialog(this, "inserido com sucesso na base de dados!");
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao inserir!");
        }
    }
    
    
    public void listarTodos(){
        ResultSet rs = mysqlr.executeQuery("SELECT * FROM classes");
        if (rs != null) {
            try {
                while (rs.next()) {            
                    model.addRow(new String[]{rs.getString("codigo"), rs.getString("descricao"), rs.getString("forca"), rs.getString("hp"), rs.getString("destresa"), rs.getString("defesa")});                    
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,"Erro: " + e);
            }
        }
    }
    
    public void alterar(Classe obj){
        int status;
        String query = "UPDATE classes SET "
                    + "descricao='" + obj.Descricao + "', "
                    + "forca=" + obj.Forca + ","
                    + " hp=" + obj.HP + ",  "
                    + "destresa=" + obj.Destresa + ", "
                    + "defesa=" + obj.Defesa + " "
                    + "WHERE codigo=" + obj.Codigo;
        status = mysqlr.executeUpdate(query);
        if (status == 1) {
            limparCampos();
            JOptionPane.showMessageDialog(this, "Alteração realizada com sucesso!");
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao realizar alteração!");
        }
    }
    
    public void excluir(int Codigo){
        String query = "DELETE FROM classes WHERE codigo=" + Codigo;
        int status = mysqlr.executeUpdate(query);
        if (status == 1) {
            JOptionPane.showMessageDialog(this, "Excluído com sucesso da base de dados!");
        } else {
            JOptionPane.showMessageDialog(this,"Erro ao excluir!");
        }  
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabelDatabase = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        TxtCodigo = new javax.swing.JTextField();
        TxtDescricao = new javax.swing.JTextField();
        jButtonInserir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TblRegistros = new javax.swing.JTable();
        jButtonListarTodos = new javax.swing.JButton();
        jButtonAlterar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        TxtHP = new javax.swing.JTextField();
        TxtDestresa = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        TxtForca = new javax.swing.JTextField();
        TxtDefesa = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        jLabel1.setText("Classes");

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel2.setText("Database:");

        jLabelDatabase.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabelDatabase.setText("OFF");

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel3.setText("Código:");

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel5.setText("Descrição:");

        TxtCodigo.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        TxtCodigo.setEnabled(false);
        TxtCodigo.setName("TxtCodigo"); // NOI18N

        TxtDescricao.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        TxtDescricao.setName("TxtDescricao"); // NOI18N

        jButtonInserir.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jButtonInserir.setText("Inserir");
        jButtonInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonInserirActionPerformed(evt);
            }
        });

        TblRegistros.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        TblRegistros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Descrição", "Força", "HP", "Destresa", "Defesa"
            }
        ));
        TblRegistros.setName("TblRegistros"); // NOI18N
        TblRegistros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TblRegistrosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TblRegistros);

        jButtonListarTodos.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jButtonListarTodos.setText("Listar");
        jButtonListarTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonListarTodosActionPerformed(evt);
            }
        });

        jButtonAlterar.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jButtonAlterar.setText("Alterar");
        jButtonAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAlterarActionPerformed(evt);
            }
        });

        jButtonExcluir.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel6.setText("HP:");

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel7.setText("Destresa:");

        TxtHP.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        TxtHP.setName("TxtHP"); // NOI18N

        TxtDestresa.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        TxtDestresa.setName("TxtDestresa"); // NOI18N

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel8.setText("Força:");

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel9.setText("Defesa:");

        TxtForca.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        TxtForca.setName("TxtForca"); // NOI18N

        TxtDefesa.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        TxtDefesa.setName("TxtDefesa"); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(TxtCodigo)
                        .addGap(12, 12, 12))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(TxtDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(10, 10, 10)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(TxtDestresa, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(TxtHP)
                        .addGap(2, 2, 2))
                    .addComponent(jLabel6))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(TxtDefesa, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(TxtForca, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
                        .addGap(2, 2, 2))
                    .addComponent(jLabel8))
                .addGap(174, 174, 174))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelDatabase))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 653, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButtonAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButtonExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButtonListarTodos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButtonInserir)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(TxtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TxtDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(TxtHP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TxtDestresa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(TxtForca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TxtDefesa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButtonInserir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonListarTodos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonAlterar)
                        .addGap(12, 12, 12)
                        .addComponent(jButtonExcluir)
                        .addGap(46, 46, 46))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabelDatabase, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel3.getAccessibleContext().setAccessibleName("Código::");
        jLabel5.getAccessibleContext().setAccessibleName("Forca");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ConfigurarCadastro(boolean IsCodigo){
        //sei que o boolean foi uma gambiarra, mas não estava conseguindo identificar se a string era vazia
        Cadastro.Forca = Integer.parseInt(TxtForca.getText());
        Cadastro.Descricao = TxtDescricao.getText();
        Cadastro.HP = Integer.parseInt(TxtHP.getText());
        Cadastro.Destresa =Integer.parseInt(TxtDestresa.getText());
        Cadastro.Defesa = Integer.parseInt(TxtDefesa.getText());
        JOptionPane.showMessageDialog(this,"tenta configurar 2");
        if(IsCodigo){
              Cadastro.Codigo = Integer.parseInt(TxtCodigo.getText());
        }
        JOptionPane.showMessageDialog(this,"tenta configurar 2");
    }
    
    private void jButtonInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonInserirActionPerformed
        ConfigurarCadastro(false);

        inserir(Cadastro);
        model.setNumRows(0);
        listarTodos();
        //inserir(jTFNome.getText(), jTFEmail.getText(), jTFCargo.getText());
    }//GEN-LAST:event_jButtonInserirActionPerformed

    private void jButtonListarTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonListarTodosActionPerformed
        model.setNumRows(0);
        listarTodos();
    }//GEN-LAST:event_jButtonListarTodosActionPerformed

    private void jButtonAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAlterarActionPerformed
        ConfigurarCadastro(true);
        
        alterar(Cadastro);
        model.setNumRows(0);
        listarTodos();
    }//GEN-LAST:event_jButtonAlterarActionPerformed

    private void TblRegistrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TblRegistrosMouseClicked
        int linha = TblRegistros.getSelectedRow();
        TxtCodigo.setText(TblRegistros.getValueAt(linha, 0)+"");
        TxtDescricao.setText(TblRegistros.getValueAt(linha, 1)+"");
        TxtHP.setText(TblRegistros.getValueAt(linha, 3)+"");
        TxtDestresa.setText(TblRegistros.getValueAt(linha, 4)+"");
        TxtForca.setText(TblRegistros.getValueAt(linha, 2)+"");
        TxtDefesa.setText(TblRegistros.getValueAt(linha, 5)+"");
        
    }//GEN-LAST:event_TblRegistrosMouseClicked

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
        ConfigurarCadastro(true);
        excluir(Cadastro.Codigo);
        model.setNumRows(0);
        listarTodos();
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmClasses.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmClasses.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmClasses.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmClasses.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmClasses().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TblRegistros;
    private javax.swing.JTextField TxtCodigo;
    private javax.swing.JTextField TxtDefesa;
    private javax.swing.JTextField TxtDescricao;
    private javax.swing.JTextField TxtDestresa;
    private javax.swing.JTextField TxtForca;
    private javax.swing.JTextField TxtHP;
    private javax.swing.JButton jButtonAlterar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonInserir;
    private javax.swing.JButton jButtonListarTodos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelDatabase;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
