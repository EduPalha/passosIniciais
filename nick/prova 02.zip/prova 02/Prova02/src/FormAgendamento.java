
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class FormAgendamento extends javax.swing.JFrame {

    MySQLR mysqlr;
    Agendamento agendamento;
    int ID_Funcionario;
    DefaultTableModel model;
    
    
    public FormAgendamento() {
        initComponents();
        model = (DefaultTableModel)(jTableAgendamento.getModel());
        mysqlr = new MySQLR();
        conectar();
        listarTodos();
        listarAgendamentos();
        this.setLocationRelativeTo(this);
        
    }
    
    public void conectar(){
        //boolean connected = mysqlr.connect("localhost", "8889", "Aula03", "root", "root");
        boolean connected = mysqlr.connect("187.181.161.253", "8889", "Aula03", "convidado", "12345");
        if (connected) {
            jLabelDatabase.setText("ON");
        } else {
            jLabelDatabase.setText("OFF");
        }
    }
    
    public void listarTodos(){
        ResultSet rs = mysqlr.executeQuery("SELECT * FROM Funcionario order by nome ASC");
        if (rs != null) {
            try {
                while (rs.next()) { 
                    jComboFuncionario.addItem(rs.getString("nome"));
                    //model.addRow(new String[]{rs.getString("ID"), rs.getString("nome"), rs.getString("email"), rs.getString("cargo")});                    
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,"Erro: " + e);
            }
        }
    }
    
    public void identificarIDFuncionario(String nome) {
        ResultSet rs = mysqlr.executeQuery("SELECT ID FROM Funcionario where nome like '"+ nome +"'");
        if (rs != null) {
            try {
                while (rs.next()) { 
                    ID_Funcionario = Integer.parseInt(rs.getString("ID"));
                    //model.addRow(new String[]{rs.getString("ID"), rs.getString("nome"), rs.getString("email"), rs.getString("cargo")});                    
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,"Erro: " + e);
            }
        }
    }
    
    public void inserir(Agendamento agendamento){
        String query = "INSERT INTO agendamento (ID_funcionario, data, hora, local, tipoCompromisso) "
                + "values ('"+agendamento.ID_Funcionario+"', '"+agendamento.data+"', '"+agendamento.hora+"', '"+agendamento.local+"', '"+agendamento.tipoCompromisso+"')";
        int status = mysqlr.executeUpdate(query);
        if (status == 1) {
            limparCampos();
            model.setNumRows(0);
            listarAgendamentos();
            JOptionPane.showMessageDialog(this, "O Agendamento foi realizado com sucesso na base de dados!");
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao inserir funcionário!");
        }
    }
    
    public void listarAgendamentos(){
        ResultSet rs = mysqlr.executeQuery("SELECT * FROM agendamento");
        if (rs != null) {
            try {
                while (rs.next()) {            
                    model.addRow(new String[]{rs.getString("ID"), rs.getString("ID_funcionario"), rs.getString("data"), rs.getString("hora"),rs.getString("local"),rs.getString("tipoCompromisso")});                    
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,"Erro: " + e);
            }
        }
    }

    
    public void limparCampos(){
        jComboFuncionario.setSelectedItem(0);
        jComboDia.setSelectedIndex(-1);
        jComboMes.setSelectedIndex(-1);
        jTFAno.setText("");
        jTFHora.setText("");
        jTFLocal.setText("");
        jTFCompromisso.setText("");
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jComboFuncionario = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jComboDia = new javax.swing.JComboBox<>();
        jComboMes = new javax.swing.JComboBox<>();
        jTFAno = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTFHora = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTFLocal = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTFCompromisso = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableAgendamento = new javax.swing.JTable();
        jButtonInserir = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabelDatabase = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        jLabel1.setText("Gerenciamento de Agendamentos");

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel3.setText("Funcionário:");

        jComboFuncionario.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jComboFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboFuncionarioActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel4.setText("Dia");

        jComboDia.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jComboDia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", " " }));
        jComboDia.setSelectedIndex(-1);

        jComboMes.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jComboMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", " " }));
        jComboMes.setSelectedIndex(-1);

        jTFAno.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel5.setText("Mês");

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel6.setText("Ano");

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel7.setText("Hora");

        jTFHora.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel8.setText("Local");

        jTFLocal.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel9.setText("Compromisso");

        jTFCompromisso.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N

        jTableAgendamento.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "ID Funcionário", "Data", "Hora", "Local", "Compromisso"
            }
        ));
        jScrollPane2.setViewportView(jTableAgendamento);

        jButtonInserir.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jButtonInserir.setText("Inserir");
        jButtonInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonInserirActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel2.setText("Database:");

        jLabelDatabase.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabelDatabase.setText("OFF");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(138, 138, 138))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jComboFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jComboDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(6, 6, 6)
                                                .addComponent(jLabel4)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jComboMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel5))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel6)
                                            .addComponent(jTFAno))))
                                .addGap(68, 68, 68)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTFHora, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTFLocal, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(jTFCompromisso, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 529, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButtonInserir))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelDatabase)))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(53, 53, 53)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFAno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFLocal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFCompromisso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonInserir))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabelDatabase, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboFuncionarioActionPerformed
        identificarIDFuncionario(jComboFuncionario.getSelectedItem()+"");
        System.out.println("ID do funcionário: " + ID_Funcionario);
    }//GEN-LAST:event_jComboFuncionarioActionPerformed

    private void jButtonInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonInserirActionPerformed
        agendamento = new Agendamento();
        agendamento.ID_Funcionario = ID_Funcionario;
        // data = YYYY/MM/DD
        agendamento.data = jTFAno.getText() + "/" + jComboMes.getSelectedItem() + "/" + jComboDia.getSelectedItem();
        agendamento.hora = jTFHora.getText();
        agendamento.local = jTFLocal.getText();
        agendamento.tipoCompromisso = jTFCompromisso.getText();
        inserir(agendamento);
    }//GEN-LAST:event_jButtonInserirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormAgendamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonInserir;
    private javax.swing.JComboBox<String> jComboDia;
    private javax.swing.JComboBox<String> jComboFuncionario;
    private javax.swing.JComboBox<String> jComboMes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelDatabase;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTFAno;
    private javax.swing.JTextField jTFCompromisso;
    private javax.swing.JTextField jTFHora;
    private javax.swing.JTextField jTFLocal;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableAgendamento;
    // End of variables declaration//GEN-END:variables
}
