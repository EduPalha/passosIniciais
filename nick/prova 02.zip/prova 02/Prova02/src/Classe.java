
public class Classe {
    
    public int Codigo;
    public String Descricao;
    public int Forca;
    public int HP;
    public int Destresa;
    public int Defesa;
    
}
