create database rpg;
use rpg;

CREATE TABLE classes (
  codigo int(11) NOT NULL AUTO_INCREMENT,
  descricao varchar(50) NOT NULL,
  forca int(11) NOT NULL,
  hp int(11) NOT NULL,
  destresa int(11) NOT NULL,
  defesa int(11) NOT NULL,
  PRIMARY KEY (codigo)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

