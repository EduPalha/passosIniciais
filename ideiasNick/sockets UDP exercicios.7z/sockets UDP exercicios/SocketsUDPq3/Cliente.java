package ex2;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente extends javax.swing.JFrame {

    DatagramSocket socket = null;

    public Cliente() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTAChat = new javax.swing.JTextArea();
        TxtCoca = new javax.swing.JTextField();
        TxtPepsi = new javax.swing.JTextField();
        TxtGuarana = new javax.swing.JTextField();
        BtnComprar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTAChat.setEditable(false);
        jTAChat.setColumns(20);
        jTAChat.setRows(5);
        jScrollPane1.setViewportView(jTAChat);

        BtnComprar.setText("Comprar");
        BtnComprar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnComprarMouseClicked(evt);
            }
        });
        BtnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnComprarActionPerformed(evt);
            }
        });

        jLabel1.setText("Coca:5,50");

        jLabel2.setText("Pepsi:4,75");

        jLabel3.setText("Guarana:5,00");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(TxtGuarana, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)
                            .addComponent(TxtPepsi)
                            .addComponent(TxtCoca))
                        .addGap(18, 18, 18)
                        .addComponent(BtnComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtCoca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtPepsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtGuarana, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Comprar() {
        ArrayList<Produto> ListaProdutos = new ArrayList<>();

        if (!TxtCoca.getText().equals("")) {
            ListaProdutos.add(new Produto("Coca", Float.parseFloat("5.50"), Integer.parseInt((TxtCoca.getText()))));
        }

        if (!TxtPepsi.getText().equals("")) {
            ListaProdutos.add(new Produto("Pepsi", Float.parseFloat("4.75"), Integer.parseInt((TxtPepsi.getText()))));
        }

        if (!TxtGuarana.getText().equals("")) {
            ListaProdutos.add(new Produto("Guarana", Float.parseFloat("5.00"), Integer.parseInt((TxtGuarana.getText()))));
        }
        EnviarCompras(ListaProdutos);
    }

    private void EnviarCompras(ArrayList<Produto> ListaProdutos) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(baos);
            oos.writeObject(ListaProdutos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Convert to Byte Array
        byte bufferEnviar[] = baos.toByteArray();

        try {
            //cria um pacote para enviar as mensagens
            DatagramPacket pacoteEnviar = new DatagramPacket(bufferEnviar, bufferEnviar.length, InetAddress.getByName("localhost"), 1235);
            //envia o pacote
            socket.send(pacoteEnviar);
        } catch (IOException ex) {
            jTAChat.append("Erro de E/S");
        }
    }

    private void Conectar() {
        try {
            this.socket = new DatagramSocket();
        } catch (SocketException ex) {
            System.out.println("Erro na criação do socket");
        }

        //thread que fica esperando mensagens do servidor
        Thread t = new Thread() {
            public void run() {
                try {
                    while (true) {
                        //cria um pacote vazio para esperar chegar uma mensagem
                        DatagramPacket pacoteRec = new DatagramPacket(new byte[1000], 1000);
                        //espera chegar um pacote pela rede
                        socket.receive(pacoteRec);
                        //retira os bytes da mensagem
                        byte bufferRec[] = pacoteRec.getData();
                        //converte em String
                        String msgRec = new String(bufferRec);
                        jTAChat.append(msgRec + "\n");
                    }
                } catch (Exception e) {
                    jTAChat.append("Servidor provavelmente caiu\n");
                }
            }
        };
        t.start();
    }

    private void BtnComprarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnComprarMouseClicked
        // Comprar();
    }//GEN-LAST:event_BtnComprarMouseClicked

    private void BtnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnComprarActionPerformed
       Conectar();
        Comprar();
    }//GEN-LAST:event_BtnComprarActionPerformed

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnComprar;
    private javax.swing.JTextField TxtCoca;
    private javax.swing.JTextField TxtGuarana;
    private javax.swing.JTextField TxtPepsi;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTAChat;
    // End of variables declaration//GEN-END:variables
}
