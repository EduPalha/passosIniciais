package ex2;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor {

    class ClienteInfo {

        InetAddress ip;
        int porta;

        public ClienteInfo(InetAddress ip, int porta) {
            this.ip = ip;
            this.porta = porta;
        }
    }

    public Servidor() {

        try {
            //cria um socket para receber pacotes dos clientes
            DatagramSocket servidor = new DatagramSocket(1235, InetAddress.getByName("localhost"));

            while (true) {
                //cria um pacote datagrama vazio para esperar mensagens dos clientes
                DatagramPacket pacoteRec = new DatagramPacket(new byte[1000], 1000);

                //aguarda chegar uma mensagem no pacote acima
                servidor.receive(pacoteRec);

                //retira os bytes do pacote
                byte bufferRec[] = pacoteRec.getData();

                InetAddress ipCliente = pacoteRec.getAddress();//ip do cliente
                int porta = pacoteRec.getPort(); //porta do cliente
                ClienteInfo cli = new ClienteInfo(ipCliente, porta); //cria um objeto com as informações do cliente

                //ArrayList<Produto> ListaProdutos = new ArrayList<>();
                ByteArrayInputStream in = new ByteArrayInputStream(bufferRec);
                ObjectInputStream is = new ObjectInputStream(in);
                ArrayList<Produto> ListaProdutos = (ArrayList<Produto>) is.readObject();

                float Valor = 0;

                for (Produto obj : ListaProdutos) {

                    String msgRec = obj.Quantidade + " " + obj.Nome + " Total " + (obj.Valor * obj.Quantidade);

                    byte bufferResposta[] = msgRec.getBytes();

                    Valor = Valor + (obj.Valor * obj.Quantidade);

                    DatagramPacket pacoteEnviar = new DatagramPacket(bufferResposta, bufferResposta.length, cli.ip, cli.porta);
                    //envia o pacote para o cliente
                    servidor.send(pacoteEnviar);
                }
                
                byte buffertotal[] = Float.toString(Valor).getBytes();
                
                 DatagramPacket pacoteEnviar = new DatagramPacket(buffertotal, buffertotal.length, cli.ip, cli.porta);
                    //envia o pacote para o cliente
                    servidor.send(pacoteEnviar);

            }

        } catch (UnknownHostException ex) {
            System.out.println("Erro de endereçamento do servidor");
        } catch (SocketException ex) {
            System.out.println("Erro de porta (porta já utilizada, provavelmente");
        } catch (IOException ex) {
            System.out.println("Erro de E/S");
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        new Servidor();
    }
}
