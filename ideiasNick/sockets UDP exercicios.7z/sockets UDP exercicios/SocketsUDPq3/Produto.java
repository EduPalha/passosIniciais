package ex2;

import java.io.Serializable;

public class Produto implements Serializable {

    String Nome;
    Float Valor;
    int Quantidade;

    public Produto(String nome, Float valor, int quantidade) {
        Nome = nome;
        Quantidade = quantidade;
        Valor = valor;
    }

    public String GetNome() {
        return Nome;
    }

    public Float GetValor() {
        return Valor;
    }
    
        public int GetQuantidade() {
        return Quantidade;
    }
}
