package ExemplosKurts.exemplo4;

public class MinhaThread extends Thread {

    public boolean ehPrimo = true;
    long inicio, fim, numeroVerificar;
    
    public void run() {
        for (long i = inicio; i < fim; i++) {
            if (numeroVerificar % i == 0) {
                ehPrimo = false;
                System.out.println("Não é primo, achei um divisor = "+i);
                break;
            }
        }
    }

}
