package ExemplosKurts.exemplo4;

public class Principal {

    
    public Principal(){
        long numeroVerificar = 1999999973;
        
        long tini = System.currentTimeMillis();
        
        //primeira metade em uma thread
        MinhaThread t1 = new MinhaThread();
        t1.inicio = 2;
        t1.fim = numeroVerificar/4;
        t1.numeroVerificar = numeroVerificar;
        
        //segunda metade em outra thread
        MinhaThread t2 = new MinhaThread();
        t2.inicio = numeroVerificar/4;
        t2.fim = numeroVerificar/2;
        t2.numeroVerificar = numeroVerificar;
        
        //terceira metade em outra thread
        MinhaThread t3 = new MinhaThread();
        t3.inicio = numeroVerificar/2;
        t3.fim = (numeroVerificar/4)*3;
        t3.numeroVerificar = numeroVerificar;
        
        //quarta metade em outra thread
        MinhaThread t4 = new MinhaThread();
        t4.inicio = (numeroVerificar/4)*3;
        t4.fim = numeroVerificar;
        t4.numeroVerificar = numeroVerificar;
        
        //inicializa as threads
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        
        //faz com que a thread principal espere pelas secundárias
        try{
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        }catch(Exception e){
            System.out.println("Erro de bloqueio");
        }
        
        long tfim = System.currentTimeMillis();
        System.out.println(tfim - tini +" milissegundos");

        if (t1.ehPrimo && t2.ehPrimo && t3.ehPrimo && t4.ehPrimo) {
            System.out.println("Eh primo");
        } else {
            System.out.println("Não eh primo");
        }
    }
    
    //fluxo principal de execução
    public static void main(String[] args) {

        Principal p = new Principal();

    }
}
