package q2;

public class ThreadContador extends Thread {

    int Numero;

    public ThreadContador(int numero) {
        Numero = numero;
    }

    public void run() {
        for (int i = 0; i <= 10000000; i++) {
            System.out.println("O numero eh:" + i + " sou a thread " + Numero);
        }
    }
}
