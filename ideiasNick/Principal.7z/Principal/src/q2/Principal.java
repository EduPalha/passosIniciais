package q2;

public class Principal {

    public static void main(String[] args) {
        
        ThreadContador t1 = new ThreadContador(1);
        ThreadContador t2 = new ThreadContador(2);

        t2.setPriority(10);
        t2.start();

        t1.setPriority(1);
        t1.start();
    }
}
