package q3;

public class ThreadMatriz extends Thread {

    int[][] Matriz;
    int Linha, Coluna;

    public ThreadMatriz(int[][] matriz, int linha) {
        Matriz = matriz;
        Linha = linha;
    }

    public void run() {
        int resultado = 0;
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if(i == Linha)
                    resultado = resultado + Matriz[i][j];
            }
        }
        
            System.out.println("A Soma dos Numeros da Linha "+Linha+" eh "+ resultado );

    }
}
