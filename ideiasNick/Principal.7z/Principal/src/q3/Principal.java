package q3;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        int[][] matriz = new int[3][3];
        Scanner ler = new Scanner(System.in);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.printf("Linha " + i + " Coluna " + j + " : ");
                matriz[i][j] = ler.nextInt();
            }
        }

        ThreadMatriz t1 = new ThreadMatriz(matriz, 0);
        ThreadMatriz t2 = new ThreadMatriz(matriz, 1);
        ThreadMatriz t3 = new ThreadMatriz(matriz, 2);

        t1.start();
        t2.start();
        t3.start();
    }

}
