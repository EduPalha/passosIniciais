package q1;

//especificação de uma thread
public class MinhaThread extends Thread {

    String Nome;
    int Numero;

    public MinhaThread(String nome, int numero) {
        Nome = nome;
        Numero = numero;
    }

    public void run() {
        while (true) {
            System.out.println("O nome eh: " + Nome + " sou a Threadh numero:" + Numero);
        }
    }
}
