package q1;

import q1.MinhaThread;

public class Principal {

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            MinhaThread t = new MinhaThread("teste"+i, i);
            t.start();
        }
    }

}
 