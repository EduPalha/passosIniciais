package q4;

import java.util.Random;

public class Threadq4 extends Thread {

    int numero, tempo;
    Random gerador = new Random();

    public Threadq4() {
        numero = gerador.nextInt(100000);
        System.out.println("Criada Thread: " + getId());
        tempo = gerador.nextInt(5);
    }

    public void run() {
        System.out.println("Iniciada Thread: " + getId() + " vou contar ate " + numero);
        for (int i = 0; i <= numero; i++) {
            System.out.println("Thread: " + getId() + " Contador: " + i);
        }
        System.out.println("Thread: " + getId() + " Entrando em Espera");
        try {
            sleep(tempo);
        } catch (Exception e) {
            System.out.println("Erro de sleep");
        }
        System.out.println("Thread: " + getId() + " Saindo da Espera");
        System.out.println("Thread: " + getId() + " Finalizada");
    }
}
