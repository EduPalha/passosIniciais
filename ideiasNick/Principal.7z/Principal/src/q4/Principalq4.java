package q4;

import java.util.Scanner;

public class Principalq4 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int Numero = 0;
        System.out.printf("Digite o Numero de Threads que Deseja Criar ");
        Numero = ler.nextInt();
        for(int i=0; i<Numero; i++){
            Threadq4 thread = new Threadq4(); 
            thread.start();
        }
    }
}