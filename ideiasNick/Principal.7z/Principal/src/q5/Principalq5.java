package q5;

import java.util.Scanner;

public class Principalq5 {

    public static void main(String[] args) {
        for (int i = 0; i < 100000; i++) {
            if (Thread.activeCount() > 9) {
                System.out.printf("existem "+Thread.activeCount()+" threads em andamento, nenhuma sera criada \n");
            } else {
                Threadq5 thread = new Threadq5();
                thread.start();
            }
            System.out.printf("Threads em andamento: "+Thread.activeCount()+"\n");
        }
    }
}
