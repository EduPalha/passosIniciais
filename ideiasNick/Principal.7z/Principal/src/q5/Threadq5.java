package q5;

import java.util.Random;

public class Threadq5 extends Thread {

    Random gerador = new Random();

    public Threadq5() {
System.out.println("Criada Thread: " + getId());
    }

    public void run() {
        System.out.println("Iniciada Thread: " + getId());
        try {
            sleep(gerador.nextInt(5));
        } catch (Exception e) {
            System.out.println("Erro de sleep");
        }
         System.out.println("Finalizada Thread: " + getId());
    }

}
